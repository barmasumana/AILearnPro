const userMessage = [
  ["hi", "hey", "hello"],
  ["how are you", "how's life", "how are things", "how are you feeling"],
  ["what are the key features of the platform?"],
  ["how do i reset my password?"],
  ["can you recommend courses for me?"],
  ["how do i enroll in a course?"],
  ["how can i contact the instructor?"],
  ["how do i navigate between different sections of a course?"],
  ["how do i change my notification settings?"],
  ["what are the available languages for courses?"],
  ["how do i make a payment for a course?"],
  ["what payment methods are accepted?"],
  ["how do i view my payment history?"],
];

const botReply = [
  ["Hello! Welcome to AiLearnPro.", "Hi there! Welcome to AiLearnPro."],
  [
    "I'm doing well, thank you. How about your learning journey?",
    "Pretty well, how's your learning going?",
    "Fantastic, are you enjoying learning?",
  ],
  [
    "Our platform offers a range of features including interactive courses, video tutorials, quizzes, assignments, and more. Additionally, you can track your progress, interact with instructors. Let me know if you need more information on any specific feature.",
  ],
  [
    "To reset your password, go to the login page and click on 'Forgot Password'. Enter your email address, and you'll receive a link to reset your password. Follow the instructions in the email to set a new password.",
  ],
  [
    "Based on your learning history and interests, I recommend the following courses: 'Advanced Data Analysis', 'Creative Writing', and 'Digital Marketing Basics'. Let me know if you want more information about any of these courses.",
  ],
  [
    "To enroll in a course, go to the courses page and browse the available courses. When you find a course you want to take, click on the 'Enroll' button. Follow the instructions to complete the enrollment process.",
  ],
  [
    "You can contact the instructor by sending them a message through the platform's messaging system. Go to the course page, find the instructor's profile, and click on 'Send Message' to write them a message.",
  ],
  [
    "You can navigate between different sections of a course using the course menu on the left side of the screen. Click on a section to view its content, including lessons, quizzes, and assignments.",
  ],
  [
    "To change your notification settings, go to your account settings and select 'Notifications'. From there, you can choose which types of notifications you would like to receive and how you want to receive them.",
  ],
  [
    "We offer courses in English, Bengali etc. Some courses may have additional language options. You can filter courses by language on the courses page.",
  ],
  [
    "To make a payment for a course, go to the course page and click on 'Enroll' or 'Buy Now.' You will be directed to the checkout page where you can choose your payment method and enter your payment details to complete the purchase.",
  ],
  [
    "We accept major credit and debit cards (Visa, Mastercard, American Express), as well as PayPal. You can choose your preferred payment method during checkout.",
  ],
  [
    "To view your payment history, go to your account settings and select 'Billing' or 'Payment History.' There, you'll find a list of your past transactions, including course purchases and any refunds.",
  ],
];

const alternative = [
  "I'm here to support your learning journey.",
  "That's intriguing! Tell me more about what you're learning.",
  "Hey there, let's talk about your learning interests.",
  "Let's shift our focus to learning. What's on your mind?",
  "Please Checkout Our AiLearnPro Website 😊",
];

const synth = window.speechSynthesis;

function voiceControl(string) {
  let u = new SpeechSynthesisUtterance(string);
  u.text = string;
  u.lang = "en-aus";
  u.volume = 1;
  u.rate = 1;
  u.pitch = 1;
  synth.speak(u);
}

function sendMessage() {
  const inputField = document.getElementById("input");
  let input = inputField.value.trim().toLowerCase(); // Convert input to lowercase for easier comparison
  input !== "" && output(input); // Use strict comparison (!==) and add chat only if input is not empty
  inputField.value = "";
}

document.addEventListener("DOMContentLoaded", () => {
  const inputField = document.getElementById("input");
  inputField.addEventListener("keydown", function (e) {
    if (e.code === "Enter") {
      let input = inputField.value.trim().toLowerCase(); // Convert input to lowercase for easier comparison
      input !== "" && output(input); // Use strict comparison (!==) and add chat only if input is not empty
      inputField.value = "";
    }
  });
});

function output(input) {
  let product = compare(userMessage, botReply, input); // Use input directly for comparison

  product = product
    ? product
    : alternative[Math.floor(Math.random() * alternative.length)];
  addChat(input, product);
}

function compare(triggerArray, replyArray, string) {
  for (let x = 0; x < triggerArray.length; x++) {
    if (triggerArray[x].includes(string)) {
      let items = replyArray[x];
      return items[Math.floor(Math.random() * items.length)];
    }
  }
  return null; // Return null if no match is found
}

function addChat(input, product) {
  const mainDiv = document.getElementById("message-section");
  let userDiv = document.createElement("div");
  userDiv.id = "user";
  userDiv.classList.add("message");
  userDiv.innerHTML = `<span id="user-response">${input}</span>`;
  mainDiv.appendChild(userDiv);

  let botDiv = document.createElement("div");
  botDiv.id = "bot";
  botDiv.classList.add("message");
  botDiv.innerHTML = `<span id="bot-response">${product}</span>`;
  mainDiv.appendChild(botDiv);
  var scroll = document.getElementById("message-section");
  scroll.scrollTop = scroll.scrollHeight;
  voiceControl(product);
}
